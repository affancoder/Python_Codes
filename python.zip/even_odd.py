#Checking even or odd
num = int(input("Enter any number: "))

if(num%2==0):
    print("number is even")
elif(num%2!=0):
    print("number is odd")
else:
    print("invalid operation")