name="Affan"
print("j" in name)