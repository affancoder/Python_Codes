print("answer is " , 10-6)
print(3*6)
print(20+8)
print(10/2)
print(10//2)#(//) for not print decimal value
print(5%2)  #%(modulo) is for reminder
print(2**5) #**(double asterisk) for power of number
    