n = input("enter the number: " )
n=int(n)
i=n
while(i>=0):
    print(i * "*")
    i=i-1