total = 0
for i in range(1,101):
    total = total + i
print(f"{total} is sum of numbers from 1 to 100")