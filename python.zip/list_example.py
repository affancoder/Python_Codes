number = [10,20,30,40]
print(number[0:3])

fact = (30,40,20)
print(fact[2])