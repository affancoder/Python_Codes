i = 5
while i >=0: #colon(:) is required is python 
    print(i * " * " and i * " ** ")
    i = i - 1