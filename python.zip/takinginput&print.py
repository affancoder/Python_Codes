name = input("who is your superhero?\n")
print("superhero "+ name)