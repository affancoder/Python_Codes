age = int(input("Input your age: "))

years_left = 100 - age
 
days = years_left * 365
months = years_left * 12         
weeks = years_left * 52

print("\n")
print(f"You have {days} days,{months} months,{weeks} weeks,{hours} hours left to live 🙂")