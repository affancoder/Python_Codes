i = 5
#i = i + 2
i += 2
i -=5 #i = i - 5

j = 9
j /=3 # i = i /3
print(i)
print(j)