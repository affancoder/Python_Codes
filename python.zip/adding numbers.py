first =input("input first number : ")
second =input("input second number :")

result = int(first) + int(second)
print(result)