n = input("enter the number: " )
n=int(n)
i=0
while(i<=n):
    print(i * "*")
    i=i+1