students = ["Aman","Affan","Arman","Bittu"]

for student in students:
        
    if student == "Arman":
        continue;
    print(student)