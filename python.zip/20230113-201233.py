for x in range(0,100):
    print(x)

#using loop in python

for numbers in range(1,50):
    print(numbers)
    
for num in range(0,100000): #: colon in required 
    print(num)
    
for t in range(9,305): #colon(:) is required
    print(t)