name = ("Md Affan Asghar")
print(name.upper())

print(name.lower())

print(name)