name = "Affan Asghar"
print(name.find("h"))