numbers = [10,20,30,[76,34],70,80]

print(numbers)

print(len(numbers))

print(numbers[3][0:2])