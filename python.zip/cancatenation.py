name = input("Who is your superhero? ")
print("Mr."+ name)