i= 1
while i<=1000000:
    print(i)
    i= i+1