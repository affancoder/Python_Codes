superhero = input("what is your superhero name? ")
print("my superhero is " + superhero)