for item in range(100):
    print(item + 1)