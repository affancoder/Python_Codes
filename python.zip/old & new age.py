old_age = input("what is your old age? ")
new_age = int(old_age) + 4
print(new_age)