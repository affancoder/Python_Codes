i=1
while(i<=1000):
    print(i)
    i=i+1