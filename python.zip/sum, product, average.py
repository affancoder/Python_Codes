first = input("enter the first number: ")
second = input("enter the second number: ")
sum = int(first) + int(second);
print(sum)
product = int(first) * int(second);
print(product)
average = (int(first) + int(second))/2;
print(average)
