n = input("enter the temperature: ")
n=int(n)
temperature = n

if temperature >= 20:
    print("hot")
    
else:
    print("cold")