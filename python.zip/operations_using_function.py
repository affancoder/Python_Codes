#opertions through function in python
#add, substrate, multiple, divide, modulo
def add(first,second):
    print(first + second)

add(10,30)

def sub(first, second):
    print(first - second)
sub(30 ,25)

def mul(first, second,third, fourth):
    print(first*second*third*fourth)

mul(3,4,5,6)

def divide(first, second):
    print(first/second)
divide(9,3)

def remainder(first, second):
    print(first%second)
remainder(5,2)