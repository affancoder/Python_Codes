#first & second are variables
first = input("input first number: ")
second = input ("input second number: ")
sum = int(first) + int(second)
print("Sum of two numbers are " + str(sum))