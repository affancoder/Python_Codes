#sum of even numbers
total = 0
for i in range(2,100,2):
    total = total + i
print(total)
    