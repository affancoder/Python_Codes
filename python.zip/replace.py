name="Affan"
print(name.replace("Affan" ,"Tony"))