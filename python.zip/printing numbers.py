for x in range (1,100):
   print(x)