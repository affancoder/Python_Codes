print (4 > 5 or 10 < 30)
print(3>2 and 10<4)