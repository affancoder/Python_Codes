first = input("enter the first number: ")
second = input("enter the second number: ")
sum = int(first) + int(second)
print("the sum is " + str(sum))