import time
timestamp = time.strftime('%H:%M:%S')
print(timestamp)

