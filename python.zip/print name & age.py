name = " Tony Stark"
age = " 51 years old"
person = " Tony is genius"
print(name)
print(age)
print(person)