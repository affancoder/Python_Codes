name = ("Md Affan Asghar")

print(name.upper())

print(name.find('h'))

print(name.replace("Md Affan Asghar","prince"))