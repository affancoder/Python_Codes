age = int(input("input your age: "))

left = 80 - age

years = left * 365 
months = left * 12
weeks = left * 52

print("\n")
print("Suppose if your life is about 80 years then\n")
print(f"You have {years} years,{months} months,{weeks} weeks left to live 🙂")