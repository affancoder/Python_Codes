for x in range(1,100):
    if x%2!=0:
        print(x)