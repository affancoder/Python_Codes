age = 10

if age >= 18:
    print("you are adult")
    print("you can vote")
    
elif age < 18 and age > 12:
    print("Your are teenager")
    
else:
    print("you are kid")