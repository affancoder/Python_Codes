a = str(input("Enter first number: "))
b = str(input("Enter second number: "))

#temp = a
#a = b
#b = temp
print("\n")
print(f"The value of a is now {a}" )
print(f"The value of b is now {b}")
print(a+b)

    