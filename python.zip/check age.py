age = input("what is your age: ")

age=int(age)

if age >= 18:
    print("you are adult & you can vote")
    
elif age < 18 and age > 12:
    print("Your are teenager")
    
else:
    print("you are kid")