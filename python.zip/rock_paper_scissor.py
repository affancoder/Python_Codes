import random
print("Rock Paper Scissors Game\n")
user_choice = int(input("Type 0 for Rock\nType 1 for Paper\nType 2 for Scissors\n\nEnter your Choice: "))
computer_choice = random.randint(0,2)
print(f"computer choose {computer_choice}\n")

if computer_choice == user_choice:
    print("It's a draw match")

elif computer_choice == 0 and user_choice == 1:
    print("You win the match")
elif computer_choice == 0 and user_choice == 2:
    print("You lose the game")
elif computer_choice == 1 and user_choice == 0:
    print("You win the match")
elif computer_choice == 1 and user_choice == 2:
    print("You win the match")
elif computer_choice == 2 and user_choice == 1:
    print("You lose the game")
elif computer_choice == 2 and user_choice == 0:
    print("You win the match")
else:
    print("invalid operation")