a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

temp = a
a = b
b = temp
print("\n")
print(f"The value of a is now {a}" )
print(f"The value of b is now {b}")

