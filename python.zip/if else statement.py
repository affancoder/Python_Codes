age = input("enter your age: ")

age= int(age)

if age >= 18:
    print("you are adult")
    print("you can vote")

elif age<=5:
    print("you are kid")
    
else:
    print("you are in school")
    