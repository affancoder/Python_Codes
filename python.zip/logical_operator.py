print (4 > 5 or 10 < 30)
#for or operation one should be true
print(3>2 and 10<4)
#for and operation both should be true
print(3>2 and 5>3)

print(not 5>2)
#not is printing reversed of result

print(not 10>15)