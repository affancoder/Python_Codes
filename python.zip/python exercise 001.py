person = ("Tony Stark")
age = 51
is_genius = True
print(person)
print(age)
print(is_genius)