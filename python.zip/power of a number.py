from math import *
print(pow(2,5))